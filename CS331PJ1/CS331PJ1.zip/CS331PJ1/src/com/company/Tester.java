package com.company;

import java.sql.Time;
import java.util.Random;

/**
 * Created by Aniratak on 4/28/2017.
 */
public class Tester {

    QuickSort qSort1 = new QuickSort();
    QuickSort2 qSort2 = new QuickSort2();
    QuickSort3 qSort3 = new QuickSort3();
    MergeSort mSort = new MergeSort();
    InsertionSort iSort = new InsertionSort();

    Random rand;
    int seed;
    Double length;
    private int[] arr;
    private int[] arr2;
    private int[] arr3;
    private int[] arr4;
    private int[] arr5;
    private int[] arr6;
    private int[] arr7;
    private int[] arr8;
    private int[] arr9;
    private int[] arr10;
    private int[] arr11;
    private int[] arr12;
    private int[] arr13;
    private int[] arr14;
    private int[] arr15;
    private int[] arr16;
    private int[] arr17;
    private int[] arr18;
    private int[] arr19;
    private int[] arr20;



    private double iniTime;
    private double finTime;
    private double diff;

    private int n = 16;          //exponent it will go to

    public void generator(){
        for(int x = 1; x <= n; x++) {
            length = Math.pow(2.0, ((double)x));
            System.out.println("The length is: " + length);
            for (int i = 0; i < 5; i++) {
                arr = new int[length.intValue()];
                arr2 = new int[length.intValue()];
                arr3 = new int[length.intValue()];
                arr4 = new int[length.intValue()];
                arr5 = new int[length.intValue()];
                arr6 = new int[length.intValue()];
                arr7 = new int[length.intValue()];
                arr8 = new int[length.intValue()];
                arr9 = new int[length.intValue()];
                arr10 = new int[length.intValue()];
                arr11 = new int[length.intValue()];
                arr12 = new int[length.intValue()];
                arr13 = new int[length.intValue()];
                arr14 = new int[length.intValue()];
                arr15 = new int[length.intValue()];
                arr16 = new int[length.intValue()];
                arr17 = new int[length.intValue()];
                arr18 = new int[length.intValue()];
                arr19 = new int[length.intValue()];
                arr20 = new int[length.intValue()];

                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr2[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr3[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr4[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr5[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr6[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr7[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr8[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr9[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr10[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr11[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr12[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr13[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr14[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr15[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr16[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr17[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr18[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr19[m] = rand.nextInt() % 100;
                }
                rand = new Random(100);
                for(int m = 0; m < length.intValue(); m++){
                    arr20[m] = rand.nextInt() % 100;
                }

                timeTester(i, x);
            }
        }
    }
    private void timeTester(int choose, int exp){
        iniTime = System.currentTimeMillis();

        switch (choose) {
            case 0:
                if(exp < 16) {
                    iSort.sort(arr);
                    iSort.sort(arr2);
                    iSort.sort(arr3);
                    iSort.sort(arr4);
                    iSort.sort(arr5);
                    iSort.sort(arr6);
                    iSort.sort(arr7);
                    iSort.sort(arr8);
                    iSort.sort(arr9);
                    iSort.sort(arr10);
                    iSort.sort(arr11);
                    iSort.sort(arr12);
                    iSort.sort(arr13);
                    iSort.sort(arr14);
                    iSort.sort(arr15);
                    iSort.sort(arr16);
                    iSort.sort(arr17);
                    iSort.sort(arr18);
                    iSort.sort(arr19);
                    iSort.sort(arr20);
                }
                else{
                    iSort.sort(arr);
                }
                break;
            case 1:
                mSort.sort(arr);
                break;
            case 2:
                qSort1.sort(arr);
                break;
            case 3:
                qSort2.sort(arr);
                break;
            case 4:
                qSort3.sort(arr);
                break;
            default:
                System.out.println("I don't even know how the hell this would be reached");
        }

        finTime = System.currentTimeMillis();

        diff = finTime - iniTime;
        System.out.println("The difference is: " + diff);

    }

    public void teest(){
        double hi = System.currentTimeMillis();
        System.out.println(hi);
    }
}
