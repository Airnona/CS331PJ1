package com.company;

import java.util.Random;

public class Main {

    public static void main(String[] args) {
        /*int[] arr = {4, 17, 3, 12, 15, 277, 82, 77, 99, 1111, 1231, 345, 34534, 3434, 23523, 62322, 232, 676, 445,325,
                876, 86, 45, 944, 822, 833, 444, 3333, 222, 111, 3444, 6655};
        for(int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
        QuickSort qSorter = new QuickSort();
        qSorter.sort(arr);

        for(int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println("\nDone with quicksort");



        int[] arr2 = {4, 17, 3, 12, 15, 277, 82, 77, 99, 1111, 1231, 345, 34534, 3434, 23523, 62322, 232, 676, 445,325,
                876, 86, 45, 944, 822, 833, 444, 3333, 222, 111, 3444, 6655};
        for(int i = 0; i < arr2.length; i++) {
            System.out.print(arr2[i] + " ");
        }
        System.out.println();

        MergeSort mSorter = new MergeSort();
        mSorter.sort(arr2);
        for(int i = 0; i < arr2.length; i++) {
            System.out.print(arr2[i] + " ");
        }
        System.out.println("\nDone with mergeSort");



        int[] arr3 = {4, 17, 3, 12, 15, 277, 82, 77, 99, 1111, 1231, 345, 34534, 3434, 23523, 62322, 232, 676, 445,325,
                876, 86, 45, 944, 822, 833, 444, 3333, 222, 111, 3444, 6655};
        for(int i = 0; i < arr3.length; i++) {
            System.out.print(arr3[i] + " ");
        }
        System.out.println();

        InsertionSort iSorter = new InsertionSort();
        iSorter.sort(arr3);
        for(int i = 0; i < arr3.length; i++) {
            System.out.print(arr3[i] + " ");
        }
        System.out.println("\nDone with insertionSort");



        int[] arr4 = {4, 17, 3, 12, 15, 277, 82, 77, 99, 1111, 1231, 345, 34534, 3434, 23523, 62322, 232, 676, 445,325,
                        876, 86, 45, 944, 822, 833, 444, 3333, 222, 111, 3444, 6655};
        for(int i = 0; i < arr4.length; i++) {
            System.out.print(arr4[i] + " ");
        }
        System.out.println();

        QuickSort2 q2Sorter = new QuickSort2();
        q2Sorter.sort(arr4);
        for(int i = 0; i < arr4.length; i++) {
            System.out.print(arr4[i] + " ");
        }
        System.out.println("\nDone with Quick Sorter 2");

        int[] arr5 = {4, 17, 3, 12, 15, 277, 82, 77, 99, 1111, 1231, 345, 34534, 3434, 23523, 62322, 232, 676, 445,325,
                876, 86, 45, 944, 822, 833, 444, 3333, 222, 111, 3444, 6655};
        for(int i = 0; i < arr5.length; i++) {
            System.out.print(arr5[i] + " ");
        }
        System.out.println();

        QuickSort3 q3Sorter = new QuickSort3();
        q3Sorter.sort(arr5);
        for(int i = 0; i < arr5.length; i++) {
            System.out.print(arr5[i] + " ");
        }
        System.out.println("\nDone with Quick Sorter 3");

        */
//        Random rand = new Random(100);
//        Double len = Math.pow(2.0, 5.0);
//        int[] arr = new int[len.intValue()];
//        for(int i = 0; i < len.intValue(); i++){
//            arr[i] = rand.nextInt()%100;
//        }
//
//        QuickSort3 qSort = new QuickSort3();
//        qSort.sort(arr);
//        for(int i = 0; i < arr.length; i++) {
//            System.out.print(arr[i] + " ");
//        }



            Tester test = new Tester();
            test.generator();
    }
}
